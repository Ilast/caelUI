local raid = {}
local display_frame = CreateFrame("Frame", "RecDamageMeter", UIParent)
local font, fontSize, fontOutline = [=[Interface\Addons\RecDamageMeter\media\neuropol x cd rg.ttf]=], 9, ""

local bit_band = bit.band
local table_sort = table.sort
local string_find = string.find
local string_format = string.format
local tonumber = tonumber
local UnitGUID = UnitGUID
local UnitName = UnitName
local GetNumRaidMembers = GetNumRaidMembers
local GetNumPartyMembers = GetNumPartyMembers
local need_reset = true
local mode = "Fight"

local function sort_total(a,b)
	return (a.total or 0) > (b.total or 0)
end

local function sort_fight(a,b)
	return (a.fight or 0) > (b.fight or 0)
end

local function SortDamage()
	if #raid and #raid > 0 then
		if mode == "Total" then
			table_sort(raid, sort_total)
		else
			table_sort(raid, sort_fight)
		end
	end
end

local UpdateDisplay = function()
	-- Sort members by damage
	SortDamage()
	
	-- If we have no data, then, zero out everything.
	if not #raid or #raid < 1 then
		for i = 1, 10 do
			display_frame.bars[i]:SetMinMaxValues(0, 1)
			display_frame.bars[i]:SetValue(0)
			display_frame.bars[i].lefttext:SetText(" ")
			display_frame.bars[i].righttext:SetText(" ")
		end
		return
	end
	
	-- Update our bars with damage done.
	for i = 1, 10 do
		if raid[1] then
			if mode == "Total" then
				display_frame.bars[i]:SetMinMaxValues(0, tonumber(raid[1].total) or 1)
			else
				display_frame.bars[i]:SetMinMaxValues(0, tonumber(raid[1].fight) or 1)
			end
		else
			display_frame.bars[i]:SetMinMaxValues(0, 1)
		end
		if raid[i] then
			if mode == "Total" and raid[i].total and raid[i].total > 0 then
				display_frame.bars[i].lefttext:SetText(raid[i].name)
				display_frame.bars[i].righttext:SetText(raid[i].total or 0)
				display_frame.bars[i]:SetValue(tonumber(raid[i].total) or 0)
			elseif raid[i].fight and raid[i].fight > 0 then
				display_frame.bars[i].lefttext:SetText(raid[i].name)
				display_frame.bars[i].righttext:SetText(raid[i].fight or 0)
				display_frame.bars[i]:SetValue(tonumber(raid[i].fight) or 0)
			else
				display_frame.bars[i].lefttext:SetText(" ")
				display_frame.bars[i].righttext:SetText(" ")
				display_frame.bars[i]:SetValue(0)
			end
			
			-- Color bar by class if we can obtain the info.
			local _, class = UnitClass(raid[i].name)
			if class then
				display_frame.bars[i]:SetStatusBarColor(RAID_CLASS_COLORS[class].r, RAID_CLASS_COLORS[class].g, RAID_CLASS_COLORS[class].b, 0.8) -- by class
			else
				display_frame.bars[i]:SetStatusBarColor(1, 1, 1, 0.8)
			end
		else
			display_frame.bars[i].lefttext:SetText(" ")
			display_frame.bars[i].righttext:SetText(" ")
			display_frame.bars[i]:SetValue(0)
		end
	end
end

local MakeButton = function()
	local f  = CreateFrame("Button", nil, display_frame)
	f:SetNormalFontObject(GameFontHighlightSmall)
	f:SetHeight(10)
	f:SetWidth(40)
	f:SetHighlightTexture("Interface\\PaperDollInfoFrame\\UI-Character-Tab-Highlight", "ADD")
	f:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background" })
	f:SetBackdropColor(.3, .3, .3, .9)
	f:SetBackdropBorderColor(.5, .5, .5, .7)
	return f
end

local MakeDisplay = function()
	local f = display_frame
	f:SetWidth(161)
	f:SetHeight(125)
	f:SetPoint("BOTTOM", UIParent, "BOTTOM", -555, 5)
	
	f.texture = f:CreateTexture()
	f.texture:SetAllPoints()
	f.texture:SetTexture(0,0,0,0)
	f.texture:SetDrawLayer("BACKGROUND")
	
	f.modetext = f:CreateFontString(nil, "ARTWORK")
	f.modetext:SetFont(font, fontSize, fontOutline)
	f.modetext:SetText(mode)
	f.modetext:SetPoint("TOP", f, "TOP", 0, 0)
	
	f.reset = MakeButton()
	f.reset:SetText("Reset")
	f.reset:SetPoint("TOPLEFT", f, "TOPLEFT", 2, -2)
	f.reset:SetScript("OnClick", function()
		raid = {}
		collectgarbage() -- force gc?
		UpdateDisplay()
		print("RecDamageMeter reset.")
	end)
	
	f.mode = MakeButton()
	f.mode:SetText("Mode")
	f.mode:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)
	f.mode:SetScript("OnClick", function()
		mode = mode == "Total" and "Fight" or "Total"
		f.modetext:SetText(mode)
		UpdateDisplay()
	end)
	
	-- Add some bars!
	f.bars = {}
	for i = 1, 10 do
		f.bars[i] = CreateFrame("StatusBar", nil, f)
		f.bars[i]:SetWidth(196)
		f.bars[i]:SetHeight(9.4)
		f.bars[i]:SetMinMaxValues(0, 1)
		f.bars[i]:SetOrientation("HORIZONTAL")
		f.bars[i]:SetStatusBarColor(1, 1, 1, 0.8)
		f.bars[i]:SetStatusBarTexture([=[Interface\Addons\RecDamageMeter\media\normTex]=])
		f.bars[i]:SetValue(0)
		f.bars[i]:SetPoint("TOPLEFT", i == 1 and f or f.bars[i-1], i == 1 and "TOPLEFT" or "BOTTOMLEFT", i == 1 and 2 or 0, i == 1 and -15 or -1.5)
		f.bars[i]:SetPoint("TOPRIGHT", i == 1 and f or f.bars[i-1], i == 1 and "TOPRIGHT" or "BOTTOMRIGHT", i == 1 and -2 or 0, i == 1 and -15 or -1.5)
		f.bars[i].lefttext = f.bars[i]:CreateFontString(nil, "ARTWORK")
		f.bars[i].lefttext:SetFont(font, fontSize, fontOutline)
		f.bars[i].lefttext:SetText(" ")
		f.bars[i].lefttext:SetPoint("LEFT", f.bars[i], "LEFT", 0, 1)
		f.bars[i].lefttext:Show()
		f.bars[i].righttext = f.bars[i]:CreateFontString(nil, "ARTWORK")
		f.bars[i].righttext:SetFont(font, fontSize, fontOutline)
		f.bars[i].righttext:SetText(" ")
		f.bars[i].righttext:SetPoint("RIGHT", f.bars[i], "RIGHT", 0, 1)
	end

	display_frame:HookScript("OnSizeChanged", function(frame, ...)
		-- Truncate bars
		local bar_room
--		bar_room = floor((RecDamageMeter:GetHeight()-40)/10)
		bar_room = floor((RecDamageMeter:GetHeight()-30.5)/RecDamageMeter.bars[1]:GetHeight())
		for i=1,10 do
			RecDamageMeter.bars[i]:Hide()
		end
		if bar_room > 0 then
			for i=1,bar_room do
				RecDamageMeter.bars[i]:Show()
			end
		end
		
		-- Resize bars
		--for i=1,10 do
			--RecDamageMeter.bars[i]:SetHeight((RecDamageMeter:GetHeight()-40)/10)
		--end
	end)
end

local ids = { p = {}, r = {}, pp = {}, rp = {} }
for i = 1, 4 do ids.p[i] = string_format("party%d", i); ids.pp[i] = string_format("partypet%d", i) end
for i = 1, 40 do ids.r[i] = string_format("raid%d", i); ids.rp[i] = string_format("raidpet%d", i) end
local function GetUnitValidity(source_guid, source_flags)

	if bit_band(source_flags, COMBATLOG_OBJECT_CONTROL_PLAYER) ~= 0 then
		if bit_band(COMBATLOG_OBJECT_AFFILIATION_MINE)~=0 then
			if source_guid == UnitGUID("player") or source_guid == UnitGUID("pet") then
				return true, UnitName("player")
			end
		end
		if bit_band(source_flags,COMBATLOG_OBJECT_AFFILIATION_RAID)~=0 then
			local num = GetNumRaidMembers() 
			if num > 0 then
				for i = 1, num do
					if source_guid == UnitGUID(ids.r[i]) or source_guid == UnitGUID(ids.rp[i]) then
						return true, UnitName(ids.r[i])
					end
				end
			end
		elseif bit_band(source_flags,COMBATLOG_OBJECT_AFFILIATION_PARTY)~=0 then
		local num = GetNumPartyMembers()
				if num > 0 then
				for i = 1, num do
					if source_guid == UnitGUID(ids.p[i]) or source_guid == UnitGUID(ids.pp[i]) then
						return true, UnitName(ids.p[i])
					end
				end
			end
		end
	end
	return false, nil
end

local ParseDamage = function(...)
	local _, cleu_event, source_guid, source_name, source_flags, dest_guid, dest_name, dest_flags = ...
	
	-- If player hurt themselves, then don't consider the data
	if source_guid == dest_guid then return end
	
	-- Make sure the player is yourself, a raid/party member, or a pet belonging to yourself or a raid/party member.
	local valid_player, owner_name = GetUnitValidity(source_guid, source_flags)
	if not valid_player then return end
	
	-- Merge pet with owner, if this is a pet
	if owner_name then
		source_name = owner_name
	end
	
	-- Remove pvp realm
	source_name = (string.find(source_name, "-", 1, true)) and string.gsub(source_name, "(.-)%-.*", "%1") or source_name

	-- Get the amount of damage done
	local amount, overkill = select(string_find(cleu_event, "SWING") and 9 or 12, ...)	
	if overkill and amount then amount = amount - overkill end
	
	-- Return the name, and amount
	return source_name, amount
end

display_frame:RegisterEvent("PLAYER_REGEN_ENABLED")
display_frame.PLAYER_REGEN_ENABLED = function(self)
-- Combat ended, flag for fight to be reset
	need_reset = true
	return
end

display_frame:RegisterEvent("PLAYER_REGEN_DISABLED")
display_frame.PLAYER_REGEN_DISABLED = function(self)
	-- Combat begun, reset fight data
	if need_reset then
		for index,info in ipairs(raid) do
			info.fight = 0
		end
		need_reset = false
	end
	UpdateDisplay()
	return
end

display_frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
display_frame.COMBAT_LOG_EVENT_UNFILTERED = function(self, event, ...)
	-- Do combat event
	local _, cleu_type = ...
	
	if string_find(cleu_type, "DAMAGE") and not string_find(cleu_type, "MISS") then
		
		-- Get sources and damage done
		local member_name, damage = ParseDamage(...)
		if not member_name or not damage then return end -- Sanity check
		
		-- Get a pointer to the member's raid table location
		local member_index
		for index, info in ipairs(raid) do
			if info.name == member_name then member_index = index end
		end
		
		-- Add member to raid table if needed
		if not member_index then
			member_index = (#raid or 0) + 1
			raid[member_index] = {}
			raid[member_index].name = member_name
		end		
		
		-- Add in their new damage.
		raid[member_index].total = (raid[member_index].total or 0) + damage
		if not need_reset then -- Only add fight data if we are in combat.
			raid[member_index].fight = (raid[member_index].fight or 0) + damage
		end
		
		UpdateDisplay()
	end
end

MakeDisplay()

local ZoneChange = function(self, zone)
	local _, instanceType = IsInInstance()
	if instanceType == "party" or instanceType == "raid" then
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:RegisterEvent("PLAYER_REGEN_ENABLED")
		self:RegisterEvent("PLAYER_REGEN_DISABLED")
		self:Show()
	else
		self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:UnregisterEvent("PLAYER_REGEN_ENABLED")
		self:UnregisterEvent("PLAYER_REGEN_DISABLED")
		self:Hide()
	end
end

display_frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
display_frame.ZONE_CHANGED_NEW_AREA = function(self)
	local zone = GetRealZoneText()
	return ZoneChange(self, zone)
end

display_frame:RegisterEvent("WORLD_MAP_UPDATE")
display_frame.WORLD_MAP_UPDATE = function(self)
	local zone = GetRealZoneText()
	if zone and zone ~= "" then
		self:UnregisterEvent("WORLD_MAP_UPDATE")
		return ZoneChange(self, zone)
	end
end

display_frame:RegisterEvent("PLAYER_ENTERING_WORLD")
display_frame.PLAYER_ENTERING_WORLD = function(self)
	return ZoneChange(self, zone)
end

function OnEvent(self, event, ...)
	if type(self[event]) == 'function' then
		return self[event](self, event, ...)
	else
		print("Unhandled event: "..event)
	end
end

display_frame:SetScript("OnEvent", OnEvent)

--[[
local ZoneChange = function(self)
	local zone = GetRealZoneText()

	if zone and zone ~= "" then
		self:UnregisterEvent("WORLD_MAP_UPDATE")
	end

	local _, instanceType = IsInInstance()
	if instanceType == "party" or instanceType == "raid" then
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:RegisterEvent("PLAYER_REGEN_ENABLED")
		self:RegisterEvent("PLAYER_REGEN_DISABLED")
		self:Show()
	else
		self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		self:UnregisterEvent("PLAYER_REGEN_ENABLED")
		self:UnregisterEvent("PLAYER_REGEN_DISABLED")
		self:Hide()
	end
end

display_frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
display_frame.ZONE_CHANGED_NEW_AREA = function(self) ZoneChange(self) end

display_frame:RegisterEvent("WORLD_MAP_UPDATE")
display_frame.WORLD_MAP_UPDATE = function(self) ZoneChange(self) end

display_frame:RegisterEvent("PLAYER_ENTRING_WORLD")
display_frame.PLAYER_ENTERING_WORLD = function(self) ZoneChange(self) end
--]]