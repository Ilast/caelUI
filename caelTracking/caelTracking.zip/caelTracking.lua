local print = function(text)
	DEFAULT_CHAT_FRAME:AddMessage("|cffD7BEA5cael|rTracking: "..tostring(text))
end

if select(2, UnitClass("player")) ~= "HUNTER" then
	print("You are not a Hunter, caelTracking will be disabled on next UI reload.")
	return DisableAddOn("caelTracking")
end

SlashCmdList["CTRACK"] = function() cTracking(UnitCreatureType("target")) end
SLASH_CTRACK1 = "/caelTracking"

local count = GetNumTrackingTypes();

cTracking = function(type)
	if (type ~= nil) then
			for i=1,count do 
				local name, _, active = GetTrackingInfo(i);
				if string.find(name, type, 0, true) then
					if (active == nil) then
						SetTracking(i);
					end
				end
			end
	end
end