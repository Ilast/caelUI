  local shapeshift_on_mouseover, petbar_on_mouseover, rightbars_on_mouseover, micromenu_on_mouseover
  local bags_on_mouseover, bar3_on_mouseover, bar2_on_mouseover, bar1_on_mouseover

  bar1_on_mouseover = 0
  bar2_on_mouseover = 0
  bar3_on_mouseover = 0
  rightbars_on_mouseover = 0
  shapeshift_on_mouseover = 0
  petbar_on_mouseover = 1
  micromenu_on_mouseover = 0
  bags_on_mouseover = 0

  ---------------------------------------------------
  -- CREATE ALL THE HOLDER FRAMES
  ---------------------------------------------------
    
  -- Frame to hold the ActionBar1 and the BonusActionBar
  local fbar1 = CreateFrame("Frame","rABS_Bar1Holder",UIParent)
  fbar1:SetWidth(243)
  fbar1:SetHeight(82)
  fbar1:SetScale(0.68625)
  fbar1:SetPoint("BOTTOM", 222, 133)  
  fbar1:Show()
  
  -- Frame to hold the MultibarLeft
  local fbar2 = CreateFrame("Frame","rABS_Bar2Holder",UIParent)
  fbar2:SetWidth(243)
  fbar2:SetHeight(82)
  fbar2:SetScale(0.68625)
  fbar2:SetPoint("BOTTOM", -222, 31)  
  fbar2:Show()

  -- Frame to hold the MultibarRight
  local fbar3 = CreateFrame("Frame","rABS_Bar3Holder",UIParent)
  fbar3:SetWidth(243)
  fbar3:SetHeight(82)
  fbar3:SetScale(0.68625)
  fbar3:SetPoint("BOTTOM", 222, 31)
  fbar3:Show()  
  
  -- Frame to hold the right bars
  local fbar45 = CreateFrame("Frame","rABS_Bar45Holder",UIParent)
  fbar45:SetWidth(243)
  fbar45:SetHeight(82)
  fbar45:SetScale(0.68625)
  fbar45:SetPoint("BOTTOM", -222, 133) 
  
  -- Frame to hold the bag buttons
  local fbag = CreateFrame("Frame","rABS_BagHolder",UIParent)
  fbag:SetWidth(220)
  fbag:SetHeight(60)
  fbag:SetScale(0.001)
  fbag:SetAlpha(0)
  fbag:SetPoint("BOTTOMRIGHT", 5, -5)
  fbag:Show()
  
  -- Frame to hold the micro menu  
  local fmicro = CreateFrame("Frame","rABS_MicroMenuHolder",UIParent)
  fmicro:SetWidth(263)
  fmicro:SetHeight(60)
  fmicro:SetScale(0.001)
  fmicro:SetAlpha(0)
  fmicro:SetPoint("TOP", 0, 5)
  fmicro:Show()
  
  -- Frame to hold the pet bars  
  local fpet = CreateFrame("Frame","rABS_PetBarHolder",UIParent)
  fpet:SetWidth(185)
  fpet:SetHeight(67)
  fpet:SetScale(0.63)
  fpet:SetPoint("BOTTOM", -533.5, 569.5) 
  
  -- Frame to hold the shapeshift bars  
  local fshift = CreateFrame("Frame","rABS_ShapeShiftHolder",UIParent)
  fshift:SetWidth(355)
  fshift:SetHeight(50)
  fshift:SetScale(0.001)
  fshift:SetAlpha(0)
  fshift:SetPoint("BOTTOM", -154, 239) 
  
  
  ---------------------------------------------------
  -- CREATE MY OWN VEHICLE EXIT BUTTON
  ---------------------------------------------------
  
  local fveb = CreateFrame("Frame","rABS_VEBHolder",UIParent)
  fveb:SetWidth(70)
  fveb:SetHeight(70)
  fveb:SetPoint("BOTTOM", -150, 279.75) 
  
  local veb = CreateFrame("BUTTON", "rABS_VehicleExitButton", fveb, "SecureActionButtonTemplate")
  veb:SetWidth(32.5)
  veb:SetHeight(32.5)
  veb:SetPoint("CENTER",0,0)
  veb:RegisterForClicks("AnyUp")
  veb:SetNormalTexture("Interface\\Vehicles\\UI-Vehicles-Button-Exit-Up")
  veb:SetPushedTexture("Interface\\Vehicles\\UI-Vehicles-Button-Exit-Down")
  veb:SetHighlightTexture("Interface\\Vehicles\\UI-Vehicles-Button-Exit-Down")
  veb:SetScript("OnClick", function(self) VehicleExit() end)
  veb:RegisterEvent("UNIT_ENTERING_VEHICLE")
  veb:RegisterEvent("UNIT_ENTERED_VEHICLE")
  veb:RegisterEvent("UNIT_EXITING_VEHICLE")
  veb:RegisterEvent("UNIT_EXITED_VEHICLE")
  veb:SetScript("OnEvent", function(self,event,...)
    local arg1 = ...
    if(((event=="UNIT_ENTERING_VEHICLE") or (event=="UNIT_ENTERED_VEHICLE")) and arg1 == "player") then
      veb:SetAlpha(1)
    elseif(((event=="UNIT_EXITING_VEHICLE") or (event=="UNIT_EXITED_VEHICLE")) and arg1 == "player") then
      veb:SetAlpha(0)
    end
  end)  
  veb:SetAlpha(0)
 
  ---------------------------------------------------
  -- MOVE STUFF INTO POSITION
  ---------------------------------------------------
  
  local i,f
  
  --bar1
  for i=1, 12 do
    _G["ActionButton"..i]:SetParent(fbar1)
  end
  ActionButton1:ClearAllPoints()
  ActionButton1:SetPoint('TOPLEFT', fbar1, 'TOPLEFT', 1, -1)

  --bonus bar  
  BonusActionBarFrame:SetParent(fbar1)
  BonusActionBarFrame:SetWidth(0.01)
  BonusActionBarTexture0:Hide()
  BonusActionBarTexture1:Hide()
  BonusActionButton1:ClearAllPoints()
  BonusActionButton1:SetPoint('TOPLEFT', fbar1, 'TOPLEFT', 1, -1)
  
  --bar2
  MultiBarBottomLeft:SetParent(fbar2)
  MultiBarBottomLeftButton1:ClearAllPoints()
  MultiBarBottomLeftButton1:SetPoint('TOPLEFT',fbar2,'TOPLEFT',1, -1)
  
  --bar3
  MultiBarBottomRight:SetParent(fbar3)
  MultiBarBottomRightButton1:ClearAllPoints()
  MultiBarBottomRightButton1:SetPoint('TOPLEFT',fbar3,'TOPLEFT',1, -1)

  BonusActionButton7:ClearAllPoints()
  BonusActionButton7:SetPoint('TOPLEFT', BonusActionButton1, 'BOTTOMLEFT', 0, -5)
  MultiBarLeftButton1:ClearAllPoints()
  MultiBarLeftButton1:SetPoint('TOPLEFT', fbar45, 'TOPLEFT', 1, -1)
  MultiBarRightButton1:ClearAllPoints()
  MultiBarRightButton1:SetPoint('TOPLEFT', fbar45, 'TOPLEFT', 1, -1)

	for i = 1, 12 do
		b1 = _G["ActionButton"..i]
		if i > 1 and i ~= 7 then
			b2 = _G["ActionButton"..i-1]
			b1:ClearAllPoints()
			b1:SetPoint("LEFT", b2, "RIGHT", 5, 0)
		elseif i == 7 then
			b2 = _G["ActionButton"..i-6]
			b1:ClearAllPoints()
			b1:SetPoint("TOPLEFT",b2,"BOTTOMLEFT",0,-6.5)
		end
	end

	for i = 1, 12 do
		b1 = _G["BonusActionButton"..i]
		if i > 1 and i ~= 7 then
			b2 = _G["BonusActionButton"..i-1]
			b1:ClearAllPoints()
			b1:SetPoint("LEFT", b2, "RIGHT", 5, 0)
		elseif i == 7 then
			b2 = _G["BonusActionButton"..i-6]
			b1:ClearAllPoints()
			b1:SetPoint("TOPLEFT",b2,"BOTTOMLEFT",0,-6.5)
		end
	end

	for i = 1, 12 do
		b1 = _G["MultiBarRightButton"..i]
		if i > 1 and i ~= 7 then
			b2 = _G["MultiBarRightButton"..i-1]
			b1:ClearAllPoints()
			b1:SetPoint("LEFT", b2, "RIGHT", 4.5, 0)
		elseif i == 7 then
			b2 = _G["MultiBarRightButton"..i-6]
			b1:ClearAllPoints()
			b1:SetPoint("TOPLEFT", b2, "BOTTOMLEFT", 0, -6.5)
		end
	end

	for i = 1, 12 do
		b1 = _G["MultiBarBottomLeftButton"..i]
		if i > 1 and i ~= 7 then
			b2 = _G["MultiBarBottomLeftButton"..i-1]
			b1:ClearAllPoints()
			b1:SetPoint("LEFT", b2, "RIGHT", 4.5, 0)
		elseif i == 7 then
			b2 = _G["MultiBarBottomLeftButton"..i-6]
			b1:ClearAllPoints()
			b1:SetPoint("TOPLEFT", b2, "BOTTOMLEFT", 0, -6.5)
		end
	end

	for i = 1, 12 do
		b1 = _G["MultiBarBottomRightButton"..i]
		if i > 1 and i ~= 7 then
			b2 = _G["MultiBarBottomRightButton"..i-1]
			b1:ClearAllPoints()
			b1:SetPoint("LEFT", b2, "RIGHT", 5, 0)
		elseif i == 7 then
			b2 = _G["MultiBarBottomRightButton"..i-6]
			b1:ClearAllPoints()
			b1:SetPoint("TOPLEFT", b2, "BOTTOMLEFT", 0, -6.5)
		end
	end

  --bags
  local BagButtons = {
    MainMenuBarBackpackButton,
    CharacterBag0Slot,
    CharacterBag1Slot,
    CharacterBag2Slot,
    CharacterBag3Slot,
    KeyRingButton,
  }  
  local function rABS_MoveBagButtons()
    for _, f in pairs(BagButtons) do
      f:SetParent(fbag)
    end
    MainMenuBarBackpackButton:ClearAllPoints()
    MainMenuBarBackpackButton:SetPoint("BOTTOMRIGHT", -15, 15)
  end  
  rABS_MoveBagButtons()  
  
  --mircro menu
  local MicroButtons = {
    CharacterMicroButton,
    SpellbookMicroButton,
    TalentMicroButton,
    AchievementMicroButton,
    QuestLogMicroButton,
    SocialsMicroButton,
    PVPMicroButton,
    LFGMicroButton,
    MainMenuMicroButton,
    HelpMicroButton,
  }

  local function rABS_MoveMicroButtons(skinName)
    for _, f in pairs(MicroButtons) do
      f:SetParent(fmicro)
    end
    CharacterMicroButton:ClearAllPoints()
    CharacterMicroButton:SetPoint("BOTTOMLEFT", 5, 5)
    SocialsMicroButton:ClearAllPoints()
    SocialsMicroButton:SetPoint("LEFT", QuestLogMicroButton, "RIGHT", -3, 0)
    UpdateTalentButton()
  end
  hooksecurefunc("VehicleMenuBar_MoveMicroButtons", rABS_MoveMicroButtons)  
  rABS_MoveMicroButtons()

  --shift
  ShapeshiftBarFrame:SetParent(fshift)
  ShapeshiftBarFrame:SetWidth(0.01)
  ShapeshiftButton1:ClearAllPoints()
  ShapeshiftButton1:SetPoint("BOTTOMLEFT",fshift,"BOTTOMLEFT",10,10)
  local function rABS_MoveShapeshift()
    ShapeshiftButton1:SetPoint("BOTTOMLEFT",fshift,"BOTTOMLEFT",10,10)
  end
  hooksecurefunc("ShapeshiftBar_Update", rABS_MoveShapeshift)  
  
  --possess bar
  PossessBarFrame:SetParent(fshift)
  PossessButton1:ClearAllPoints()
  PossessButton1:SetPoint("BOTTOMLEFT", fshift, "BOTTOMLEFT", 10, 10)
  
  --pet
  PetActionBarFrame:SetParent(fpet)
  PetActionBarFrame:SetWidth(0.01)
  PetActionButton1:ClearAllPoints()
  PetActionButton1:SetPoint('TOPLEFT',fpet,'TOPLEFT',1, -1)
  PetActionButton6:ClearAllPoints()
  PetActionButton6:SetPoint('TOPLEFT',PetActionButton1,'BOTTOMLEFT',0,-5)

  --right bars
  MultiBarRight:SetParent(fbar45)
  MultiBarLeft:SetParent(fbar45)
  MultiBarRight:ClearAllPoints()
  MultiBarRight:SetPoint("TOPRIGHT",-10,-10)
  
  ---------------------------------------------------
  -- ACTIONBUTTONS MUST BE HIDDEN
  ---------------------------------------------------
  
  -- hide actionbuttons when the bonusbar is visible (rogue stealth and such)
  local function rABS_showhideactionbuttons(alpha)
    local f = "ActionButton"
    for i=1, 12 do
      _G[f..i]:SetAlpha(alpha)
    end
  end
  BonusActionBarFrame:HookScript("OnShow", function(self) rABS_showhideactionbuttons(0) end)
  BonusActionBarFrame:HookScript("OnHide", function(self) rABS_showhideactionbuttons(1) end)
  if BonusActionBarFrame:IsShown() then
    rABS_showhideactionbuttons(0)
  end

  ---------------------------------------------------
  -- ON MOUSEOVER STUFF
  ---------------------------------------------------

  --functions  
  local function rABS_showhidebar1(alpha)
    if BonusActionBarFrame:IsShown() then
      for i=1, 12 do
        local pb = _G["BonusActionButton"..i]
        pb:SetAlpha(alpha)
      end
    else
      for i=1, 12 do
        local pb = _G["ActionButton"..i]
        pb:SetAlpha(alpha)
      end
    end
  end
  
  
  local function rABS_showhidebar2(alpha)
    if MultiBarBottomLeft:IsShown() then
      for i=1, 12 do
        local pb = _G["MultiBarBottomLeftButton"..i]
        pb:SetAlpha(alpha)
      end
    end
  end
  
  local function rABS_showhidebar3(alpha)
    if MultiBarBottomRight:IsShown() then
      for i=1, 12 do
        local pb = _G["MultiBarBottomRightButton"..i]
        pb:SetAlpha(alpha)
      end
    end
  end
  
  local function rABS_showhideshapeshift(alpha)
    for i=1, NUM_SHAPESHIFT_SLOTS do
      local pb = _G["ShapeshiftButton"..i]
      pb:SetAlpha(alpha)
    end
  end
  
  local function rABS_showhidepet(alpha)
    for i=1, NUM_PET_ACTION_SLOTS do
      local pb = _G["PetActionButton"..i]
      pb:SetAlpha(alpha)
    end
  end
  
  local function rABS_showhiderightbar(alpha)
    if MultiBarLeft:IsShown() then
      for i=1, 12 do
        local pb = _G["MultiBarLeftButton"..i]
        pb:SetAlpha(alpha)
      end
    end
    if MultiBarRight:IsShown() then
      for i=1, 12 do
        local pb = _G["MultiBarRightButton"..i]
        pb:SetAlpha(alpha)
      end
    end
  end
  
  local function rABS_showhidemicro(alpha)
    for _, frame in pairs(MicroButtons) do
      frame:SetAlpha(alpha)
    end
  end
  
  local function rABS_showhidebags(alpha)
    for _, frame in pairs(BagButtons) do
      frame:SetAlpha(alpha)
    end
  end

  --calls  
  if bar1_on_mouseover == 1 then
    fbar1:EnableMouse(true)
    fbar1:SetScript("OnEnter", function(self) rABS_showhidebar1(1) end)
    fbar1:SetScript("OnLeave", function(self) rABS_showhidebar1(0) end)  
    for i=1, 12 do
      local pb = _G["ActionButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhidebar1(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhidebar1(0) end)
      local pb = _G["BonusActionButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhidebar1(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhidebar1(0) end)
    end
  end
  
  if bar2_on_mouseover == 1 then
    fbar2:EnableMouse(true)
    fbar2:SetScript("OnEnter", function(self) rABS_showhidebar2(1) end)
    fbar2:SetScript("OnLeave", function(self) rABS_showhidebar2(0) end)  
    for i=1, 12 do
      local pb = _G["MultiBarBottomLeftButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhidebar2(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhidebar2(0) end)
    end
  end
  
  if bar3_on_mouseover == 1 then
    fbar3:EnableMouse(true)
    fbar3:SetScript("OnEnter", function(self) rABS_showhidebar3(1) end)
    fbar3:SetScript("OnLeave", function(self) rABS_showhidebar3(0) end)  
    for i=1, 12 do
      local pb = _G["MultiBarBottomRightButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhidebar3(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhidebar3(0) end)
    end
  end
  
  if shapeshift_on_mouseover == 1 then
    fshift:EnableMouse(true)
    fshift:SetScript("OnEnter", function(self) rABS_showhideshapeshift(1) end)
    fshift:SetScript("OnLeave", function(self) rABS_showhideshapeshift(0) end)  
    for i=1, NUM_SHAPESHIFT_SLOTS do
      local pb = _G["ShapeshiftButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhideshapeshift(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhideshapeshift(0) end)
    end
  end
  
  if petbar_on_mouseover == 1 then
    fpet:EnableMouse(true)
    fpet:SetScript("OnEnter", function(self) rABS_showhidepet(1) end)
    fpet:SetScript("OnLeave", function(self) rABS_showhidepet(0) end)  
    for i=1, NUM_PET_ACTION_SLOTS do
      local pb = _G["PetActionButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhidepet(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhidepet(0) end)
    end
  end
  
  if rightbars_on_mouseover == 1 then
    fbar45:EnableMouse(true)
    fbar45:SetScript("OnEnter", function(self) rABS_showhiderightbar(1) end)
    fbar45:SetScript("OnLeave", function(self) rABS_showhiderightbar(0) end)  
    for i=1, 12 do
      local pb = _G["MultiBarLeftButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhiderightbar(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhiderightbar(0) end)
      local pb = _G["MultiBarRightButton"..i]
      pb:SetAlpha(0)
      pb:HookScript("OnEnter", function(self) rABS_showhiderightbar(1) end)
      pb:HookScript("OnLeave", function(self) rABS_showhiderightbar(0) end)
    end
  end
  
  if micromenu_on_mouseover == 1 then
    fmicro:EnableMouse(true)
    fmicro:SetScript("OnEnter", function(self) rABS_showhidemicro(1) end)
    fmicro:SetScript("OnLeave", function(self) rABS_showhidemicro(0) end)  
    for _, f in pairs(MicroButtons) do
      f:SetAlpha(0)
      f:HookScript("OnEnter", function(self) rABS_showhidemicro(1) end)
      f:HookScript("OnLeave", function(self) rABS_showhidemicro(0) end)
    end
  end
  
  if bags_on_mouseover == 1 then
    fbag:EnableMouse(true)
    fbag:SetScript("OnEnter", function(self) rABS_showhidebags(1) end)
    fbag:SetScript("OnLeave", function(self) rABS_showhidebags(0) end)  
    for _, f in pairs(BagButtons) do
      f:SetAlpha(0)
      f:HookScript("OnEnter", function(self) rABS_showhidebags(1) end)
      f:HookScript("OnLeave", function(self) rABS_showhidebags(0) end)
    end  
  end

  ---------------------------------------------------
  -- MAKE THE DEFAULT BARS UNVISIBLE
  ---------------------------------------------------
  
  local FramesToHide = {
    MainMenuBar,
    VehicleMenuBar,
  }  
  
  local function rABS_HideDefaultFrames()
    for _, f in pairs(FramesToHide) do
      f:SetScale(0.001)
      f:SetAlpha(0)
    end
  end  
  rABS_HideDefaultFrames()