local reagents = {
	["The Maelstrom"] = {
		["Caellian"] = {[31737] = 18000, [33445] = 40, [35953] = 40},
		["Pimiko"] = {[33445] = 40}
	}
}

local class = nil
local realm = nil
local name = nil
local select = select

local GetReagentsLite = CreateFrame("Frame", "GetReagentsLite", UIParent)

local HowMany = function(checkid)
	if not reagents[realm][name][checkid] then return 0 end
	local total = 0
	for bag = 0, NUM_BAG_FRAMES do
		for slot = 1, GetContainerNumSlots(bag) do
			local link = GetContainerItemLink(bag, slot)
			if (link) then
				local id = select(3, string.find(link, "item:(%d+)"))
				local stack = select(2, GetContainerItemInfo(bag, slot))
				if tonumber(id) == tonumber(checkid) then total = total + stack end
			end
		end
	end
	return max(0, (reagents[realm][name][checkid] - total))
end

local BuyReagents = function()	
	for i=1, GetMerchantNumItems() do
		local link, id = GetMerchantItemLink(i)
		if link then id = tonumber(select(3, string.find(link, "item:(%d+)"))) end
		if id and reagents[realm][name][id] then
			local price, stack, stock = select(3, GetMerchantItemInfo(i))
			local quantity = HowMany(id)
			if quantity > 0 then
				if stock ~= -1 then quantity = min(quantity, stock) end
				subtotal = price * quantity
				if subtotal > GetMoney() then DEFAULT_CHAT_FRAME:AddMessage("GetReagents-Lite: Not enough money.") return end
				local fullstack = select(8, GetItemInfo(id))
				while quantity > fullstack do
					BuyMerchantItem(i, floor(fullstack/stack))
					quantity = quantity - fullstack
				end
				if quantity >= stack then BuyMerchantItem(i, floor(quantity/stack)) end
			end
		end
	end
end

function GetReagentsLite:MERCHANT_SHOW()
	if not class then
		class = select(2, UnitClass("player"))
	end

	if not name then
		name = UnitName("player")
	end

	if not realm then
		realm = GetRealmName()
	end

	if reagents[realm][name] then
		BuyReagents()
	end
end

GetReagentsLite:SetScript("OnEvent", function (frame, event) GetReagentsLite[event](GetReagentsLite) end) 
GetReagentsLite:RegisterEvent("MERCHANT_SHOW")